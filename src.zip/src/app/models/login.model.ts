export interface LoginModel {
  readonly data: {
     email: string;
     password: string;
  }
}
