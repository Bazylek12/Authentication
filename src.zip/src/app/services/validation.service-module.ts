import { NgModule } from '@angular/core';
import { ValidationService } from './validation.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [ValidationService],
  exports: []
})
export class ValidationServiceModule {
}
